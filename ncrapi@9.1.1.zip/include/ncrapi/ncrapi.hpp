#pragma once

#include "ncrapi/chassis/chassis.hpp"
#include "ncrapi/generic/generic.hpp"
#include "ncrapi/system/logger.hpp"
#include "ncrapi/system/sysBase.hpp"
#include "ncrapi/userDisplay/userDisplay.hpp"

#define NCR_VERSION_STRING "9.1.1"
