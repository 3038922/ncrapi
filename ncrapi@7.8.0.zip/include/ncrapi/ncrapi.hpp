#pragma once

#include "ncrapi/chassis/chassis.hpp"
#include "ncrapi/generic/generic.hpp"
#include "ncrapi/system/systemData.hpp"
#include "ncrapi/userDisplay/userDisplay.hpp"

#define NCR_VERSION_STRING "7.8.0"
